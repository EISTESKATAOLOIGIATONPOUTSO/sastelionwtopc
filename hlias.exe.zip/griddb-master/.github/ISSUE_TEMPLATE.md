This is a textarea for an issue about griddb/griddb_nosql repository.

**REMOVE THE TEXT ABOVE BEFORE CREATING THE ISSUE**