This product contains third-party libraries as below.

This product contains software from Apache License, Version 2.0(http://www.apache.org/licenses/LICENSE-2.0)
(MessagePack, ActiveMQ-CPP, Apache Portable Runtime, json-simple, and omaha).
See below for the copyrights and terms of use/disclaimers of the respective software. 
                #  
                3rd_party/Apache_License-2.0.txt  
                3rd_party/activemq-cpp-library  
                3rd_party/apr  
                3rd_party/MessagePack  
                3rd_party/json-simple (the source code is in java_client/src_contrib/com/toshiba/mwcloud/gs/contrib/org/json)
                3rd_party/omaha
  
This product contains software from The MIT License (http://opensource.org/licenses/MIT) 
(libebb and SLF4J).
See below for the copyrights and terms of use/disclaimers of the respective software. 
                #  
                3rd_party/MIT_License.txt  
                3rd_party/ebb  
                3rd_party/slf4j  

This product contains software from BSD License(http://opensource.org/licenses/BSD-3-Clause or
 http://opensource.org/licenses/BSD-2-Clause) (picojson, sha2, purewell, yield, and ZigZag encoding).
See below for the copyrights and terms of use/disclaimers of the respective software. 
                #  
                3rd_party/BSD_License.txt  
                3rd_party/sha2  
                3rd_party/picojson  
                3rd_party/pure_well (the source code is in utility/util)  
                3rd_party/yield (the source code is in utility/util)  
                3rd_party/uuid  
                3rd_party/zigzag_encoding (the source code is in utility/util)  

